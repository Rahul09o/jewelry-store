document.addEventListener('DOMContentLoaded', () => {
    const products = [
        { name: 'Diamond Ring', price: '$5000', image: 'images/diamond-ring.jpg' },
        { name: 'Gold Necklace', price: '$3000', image: 'images/gold-necklace.jpg' },
        { name: 'Silver Bracelet', price: '$1500', image: 'images/silver-bracelet.jpg' }
    ];

    const productGrid = document.querySelector('.product-grid');
    products.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product-item');
        productItem.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price}</p>
        `;
        productGrid.appendChild(productItem);
    });
});